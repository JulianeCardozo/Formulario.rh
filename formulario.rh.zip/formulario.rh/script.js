const botaoImprimir = document.getElementById("imprimir");
const formulario = document.getElementById("formulario");

botaoImprimir.addEventListener("click", () => {
  window.print();
});

formulario.addEventListener("reset", (evento) => {
  const confirmado = window.confirm(
    "Deseja limpar todos os campos preenchidos?"
  );

  if (!confirmado) {
    evento.preventDefault();
  }
});